<?php
/**
 * @package pragyan
 * @copyright (c) 2008 Pragyan Team
 * @license http://www.gnu.org/licenses/ GNU Public License
 * For more details, see README
 */

function resetPasswd() {
	if((!isset($_POST['user_email']))&&(!isset($_GET['key']))) {
		$resetPasswd =<<<RESET
					<form class="registrationform" method="POST" name="user_passreset" onsubmit="return checkForm(this)" action="./+login&subaction=resetPasswd">
						<fieldset>
						<legend>Reset Password</legend>
							<table>
								<tr>
									<td><label for="user_email"  class="labelrequired">Email</label></td>
									<td><input type="text" name="user_email" id="user_email" class="required" onchange="if(this.length!=0) return checkEmail(this);"/><br /></td>
								</tr>
								<tr>
									<td colspan="2">&nbsp;</td>
								</tr>
								<tr>
									<td><input type="submit" id="submitbutton" value="Submit"></td>
									<td><a href='./+login&subaction=register'>Sign Up</a> <a href="./+login">Login</a></td>
								</tr>
							</table>
						</fieldset>
					</form>
RESET;
		return $resetPasswd;
	}
	elseif(!isset($_GET['key'])) {
						$user_email = $_GET['user_email'];
						if (!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $_POST['user_email']))
							displayerror("Invalid Email Id. <br /><input type=\"button\" onclick=\"history.go(-1)\" value=\"Go back\" />");
						else {
							$query = "SELECT * FROM `" . MYSQL_DATABASE_PREFIX . "users` WHERE `user_email`='$_POST[user_email]' ";
							$result = mysql_query($query);
							$temp = mysql_fetch_assoc($result);
							if (mysql_num_rows($result) == 0)
								displayerror("E-mail not in registered accounts list. <br /><input type=\"button\" onclick=\"history.go(-1)\" value=\"Go back\" />");
							elseif ($temp['user_activated'] == 0) {
								displayerror("Account not yet activated.<b>Please check your email</b> and click on the activation link. <a href=\"./+login&subaction=register&reSendKey=1\">Resend activation mail?</a><br /><input type=\"button\" onclick=\"history.go(-1)\" value=\"Go back\" />");
							} else {
								
								$server = $_SERVER['SCRIPT_URI'];
								$key = md5($temp['user_password'].'xXc'.substr($temp['user_email'],1,2));
								
								// send mail code starts here - see common.lib.php for more
								$from = "no-reply@pragyan.org";
								$to = "$temp[user_email]";
								$mailtype = "password_reset";
								$language = "en";
								
								$messenger = new messenger(false);
				
								$messenger->assign_vars(array('ACTIVATE_URL'=>"http://pragyan.org/08/home/+login&subaction=resetPasswd&resetPasswd=$temp[user_email]&key=$key",
															'NAME'=>"$temp[user_fullname]"));
				
								if ($messenger->mailer($from,$to,$mailtype,$language,$key))
									displayinfo("Password reset link sent. Kindly check your e-mail. <br /><input type=\"button\" onclick=\"history.go(-2)\" value=\"Go back\" />");
								else 
									displayerror("Password reset failed. Kindly contact webadmin@pragyan.org");
								// send mail code ends here
								
							}
						}
	}
	else {
					$key = $_GET['key'];
					$user_email = $_GET['resetPasswd'];
					$password = rand();
					$dbpassword = md5($password);
					$query = "SELECT * FROM `" . MYSQL_DATABASE_PREFIX . "users` WHERE `user_email`='" . $user_email . "'";
					$result = mysql_query($query);
					$temp = mysql_fetch_assoc($result);
					if ($key == md5($temp['user_password'].'xXc'.substr($temp['user_email'],1,2))) {
						$query = "UPDATE `" . MYSQL_DATABASE_PREFIX . "users`  SET `user_password`='$dbpassword' WHERE `user_email`='$user_email'";
						$result = mysql_query($query);
						if (mysql_affected_rows() > 0) { 
							// send mail code starts here
							$from = "no-reply@pragyan.org";
							$to = "$temp[user_email]";
							$mailtype = "password_reset";
							$language = "en";
							
							$messenger = new messenger(false);
			
							$messenger->assign_vars(array('PASSWORD'=>"$password",
														'NAME'=>"$temp[user_fullname]"));
			
							if ($messenger->mailer($from,$to,$mailtype,$language,$key))
								displayinfo("Password reset. Kindly check your e-mail.");
							else 
								displayerror("Password reset failed. Kindly contact webadmin@pragyan.org");
							// send mail code ends here
			
						}
					} else
						displayinfo("Authentication failure for password reset for $user_email");
	}
	return "";
}

function login() {
	if(isset($_GET['subaction'])) {
		if($_GET['subaction']=="resetPasswd") {
			return resetPasswd();
		}
		if($_GET['subaction']=="register") {
			require_once("registration.lib.php");
			return register();
		}
	}
	if (!isset ($_POST['user_email'])) {
		$login_str =<<<LOGIN
					<script language="javascript" type="text/javascript">
					<!--
					function checkLoginForm(inputhandler) {
						if(inputhandler.user_password.value.length==0) {
							alert("Blank password not allowed.");
							return false;
						}
						return checkEmail(this.user_email);
					}
					-->
					</script>
					<form method="POST" class="registrationform" name="user_loginform" onsubmit="return checkLoginForm(this);" action="./+login">
						<fieldset>
						<legend>Login</legend>
							<table>
								<tr>
									<td><label for="user_email"  class="labelrequired">Email</label></td>
									<td><input type="text" name="user_email" id="user_email" class="required" onchange="if(this.length!=0) return checkEmail(this);"/><br /></td>
								</tr>
								<tr><td><label for="user_password" class="labelrequired">Password</label></td>
									<td><input type="password" name="user_password"  id="user_password"  class="required" /><br /></td>
								</tr>
								<tr>
									<td><br /><input type="submit" value="Login" /></td>
									<td><a href="./+login&subaction=resetPasswd">Lost Password?</a> <a href="./+login&subaction=register">Sign Up</a></td>
								</tr>
							</table>
						</fieldset>
					</form>
LOGIN;
		return $login_str;
	} else {
			
			/*if it is, 
							then userLDAPVerify($user_email,$user_passwd);
							if the password is correct, update his password in DB
							else $dontloginLDAP = true;
					}
					else {
						if(userLDAPVerify($user_email,$user_passwd)) {
							create his row in DB with loginmethod = ldap and user_activated = 1
							(for this, use the createUser funciton in common.lib.php)
						}
					}*/
					
			
			global $cookieSupported;
			$login_status = false;
			if($cookieSupported==true) {
				if ((($_POST['user_email']) == "") || (($_POST['user_password']) == ""))
					displayerror("Blank e-mail or password NOT allowed. <br /><input type=\"button\" onclick=\"history.go(-1)\" value=\"Go back\" />");
				else {
					$user_email = $_POST['user_email'];
					$user_passwd = $_POST['user_password'];
					
					if($temp = getUserInfo($user_email)) { // chk if existsInDB
						$login_status = checkLogin($temp['user_loginmethod'],$temp['user_name'],$user_email,$user_passwd);
						updateUserPassword($user_email,$user_passwd); //update passwd in db
						}
					else {
						$login_methods = array('imap','ldap','ads');
						$user_name = strstr($user_email,'@',true); // extract username from useremail : eg.name@nitt.edu will give 'name'
						foreach ($login_methods as $login_method) { 
							// check all login methods in the order given in array
							if($login_status = checkLogin($login_method,$user_name,$user_email,$user_passwd)) {
								$user_fullname = strtoupper($user_name);
								//create new user in db and activate the user
								$query = "INSERT INTO `" . MYSQL_DATABASE_PREFIX . "users` " .
								"(`user_name`, `user_email`, `user_fullname`, `user_password`, `user_loginmethod`, `user_activated`) " .
								"VALUES ('{$user_name}', '{$user_email}', '{$user_fullname}', '{$user_passwd}', '{$login_method}', '1')";
								mysql_query($query) or die(mysql_error() . " creating new user !");
														
								break;
							}
						}						
					}
				
					if($login_status) {
						if (!$temp['user_activated']) {
							displayinfo("The e-mail has not yet been verified. Kindly check your email and click on verification link. <br /><input type=\"button\" onclick=\"history.go(-1)\" value=\"Go back\" />");
							// if user exists in db and admin has set user_activated = false delibrately
							// then it means that the user has been denied access !!!
							}
						else {
							$query = "UPDATE `" . MYSQL_DATABASE_PREFIX . "users` SET `user_lastlogin`=NOW() WHERE `" . MYSQL_DATABASE_PREFIX . "users`.`user_id` =$temp[user_id]";
							mysql_query($query) or die(mysql_error() . " in login.lib.L:111");
							$_SESSION['last_to_last_login_datetime']=$temp['user_lastlogin'];
							setAuth($temp['user_id']);
							displayinfo("Welcome " . $temp['user_name'] . "!");
							return $temp['user_id'];
							}
						}
					else {
						displaywarning("Wrong E-mail or password. <a href='./+login&subaction=resetPasswd'>Lost Password?</a><br /><input type=\"button\" onclick=\"history.go(-1)\" value=\"Go back\" />");
					}
				}
				return 0;
			} else {
				showCookieWarning();
				return 0;
			}
	}
}


function checkLogin($login_method,$user_name,$user_email,$user_passwd) {
	$login_status=false;
	switch($login_method)	//get his login method, and chk credentials
		{
			case 'ads':
				displayinfo("put some code for ADS login");
				break;
			case 'ldap':
				$login_status = my_ldap_auth($user_name, $user_passwd);
				break;
			case 'imap':
				$login_status = my_imap_auth($user_email, $user_passwd);
				break;
			default:
				$temp = getUserInfo($user_email);
				if(md5($user_passwd)==$temp['user_password']) {
					$login_status = true;
				}
		}
	return $login_status;
						
}

/***FUNCTIONS FOR IMAP AUTH: ***/
function quoteIMAP($str)
{
  return ereg_replace("([\"\\])", "\\1", $str);
}

function my_imap_auth ($username, $password, $imap_server_address="178.1.1.15", $imap_port=143)
{
  $imap_stream = fsockopen ( $imap_server_address, $imap_port);
  if ( !$imap_stream ) {
    return false;
  }
  $server_info = fgets ($imap_stream, 1024);

  $query = 'b221 ' .  'LOGIN "' . quoteIMAP($username) .  '" "'  .quoteIMAP($password) . "\"\r\n";
  $read = fputs ($imap_stream, $query);

  $response = fgets ($imap_stream, 1024);
  $query = 'b222 ' . 'LOGOUT';
  $read = fputs ($imap_stream, $query);
  fclose($imap_stream);

  strtok($response, " ");
  $result = strtok(" ");

  if($result == "OK")
    return true;
  else
    return false;
}

/**FUNCTION FOR ADS AUTH:***/
// where is the code .. sahil ?? :(

/**FUNCTION FOR LDAP AUTH:***/
function my_ldap_auth ($username, $password) {

  $ldapconn=ldap_connect("10.0.0.2");
  if($ldapconn)
    {
      $ldap_bind=ldap_bind($ldapconn, "NITT\\".$username, $password);
    }
		
  if($ldap_bind && $password!='')
    {
      return TRUE;
    }
  else
    return FALSE;

}

