<?
$sph_messages =  Array (
	"Categories" => "Kategorije",
	"CATEGORIES" => "KATEGORIJE",
	"Untitled" => "Dokument brez naslova",
	"Powered by" => "Uporablja",
	"Previous" => "Prej&scaron;nja",
	"Next" => "Naslednja",
	"Result page" => "Rezultati iskanja",
	"Only in category" => "Samo v kategoriji",
	"Search" => "I&scaron;&#269;i",
	"All sites" => "Vse strani",
	"Web pages" => "Spletne strani",
	"noMatch" => "Poizvedba \"%query\" se ne ujema z nobenim dokumentom",
	"ignoredWords" => "Naslednje besede so bile ignorirane (so prekratke ali prepogoste): %ignored_words",
	"resultsFor" => "Rezultati za:",
	"Results" => "Zadetki %from - %to od %all %matchword (%secs sekunde)", //
	"match" => "najdenih",     //
	"matches" => "najdenih", //
	"andSearch" => "Iskanje IN",         
	"orSearch" => "Iskanje ALI",    
	"phraseSearch" => "Iskanje besednih zvez oziroma stavkov",
	"show" => "Prika&#382;i",
	"resultsPerPage" => "zadetkov na stran",
	"DidYouMean" => "Did you mean"
);
?>