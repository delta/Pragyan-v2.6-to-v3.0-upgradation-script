<?php 
$sph_messages =  Array (
	"Categories" => "Categories",
	"CATEGORIES" => "CATEGORIES",
	"Untitled" => "Document sans titre",
	"Powered by" => "Powered by",
	"Previous" => "Pr�c�dent",
	"Next" => "Suivant",
	"Result page" => "Page de r�sultat",
	"Only in category" => "Seulement dans la cat�gorie",
	"Search" => "Chercher",
	"All sites" => "Tous les sites",
	"Web pages" => "Pages Web",
	"noMatch" => "La recherche \"%query\" ne correspond � aucun document",
	"ignoredWords" => "Mots vides ignor�s (trop court ou commun): %ignored_words",
	"resultsFor" => "R�sultats pour:",
	"Results" => "Pr�sentation des r�sultats %from - %to ode %all %matchword (%secs secondes)", //
	"match" => "resultat",     //
	"matches" => "resultats", //
	"andSearch" => "Recherhe ET",         
	"orSearch" => "Recherche OU",    
	"phraseSearch" => "Recherche d'expression",
	"show" => "Montrer ",
	"resultsPerPage" => "r�sultats par page",
	"DidYouMean" => "Did you mean"

);
?>