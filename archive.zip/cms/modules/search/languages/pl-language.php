<?php 
$sph_messages =  Array (
	"Categories" => "Kategorie",
	"CATEGORIES" => "KATEGORIE",
	"Untitled" => "Bez tytu�u",
	"Powered by" => "Powered by",
	"Previous" => "Poprzednie",
	"Next" => "Nast�pne",
	"Result page" => "Wyniki wyszukiwania",
	"Only in category" => "Tylko w kategorii",
	"Search" => "Szukaj",
	"All sites" => "Wszystkie strony",
	"Web pages" => "Strony WWW",
	"noMatch" => "�aden dokument nie pasowa� do zapytania \"%query\"",
	"ignoredWords" => "Nast�puj�ce s�owa zosta�y zignorowane: %ignored_words",
	"resultsFor" => "Wyniki wyszykiwania dla:",
	"Results" => "Wy�wietlanie wynik�w %from - %to z %all %matchword (%secs sekund)", //
	"of" => " z",           //Pattern:  Results x-y of z match(es). Change according to the pattern
	"match" => "match",     //
	"matches" => "pasuj�cych", //
	"seconds" => "sekund",
	"andSearch" => "AND",         
	"orSearch" => "OR",    
	"phraseSearch" => "Wyszykiwanie frazy",
	"show" => "Poka� ",
	"resultsPerPage" => "wynik�w na stronie",
	"DidYouMean" => "Did you mean"
);
?>