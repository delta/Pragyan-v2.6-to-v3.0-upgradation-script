function menuItemMouseOver(e) {
	var descriptionDiv = this.parentNode;
	while (descriptionDiv.tagName.toLowerCase() != 'div')
		descriptionDiv = descriptionDiv.parentNode;
	while (descriptionDiv.className != 'menuitemdescription')
		descriptionDiv = descriptionDiv.previousSibling;
	descriptionDiv.innerHTML = this.alt;
	this.style.filter = 'alpha(opacity=100)';
}

function menuItemMouseOut(e) {
	var descriptionDiv = this;
	while (descriptionDiv.tagName.toLowerCase() != 'div')
		descriptionDiv = descriptionDiv.parentNode;
	while (descriptionDiv.className != 'menuitemdescription')
		descriptionDiv = descriptionDiv.previousSibling;
	descriptionDiv.innerHTML = '&nbsp;';
	this.style.filter = 'alpha(opacity=85)';
}

function setupMenubar() {
	var menuImages = document.getElementById('menubar').getElementsByTagName('img');
	for (var i = 0; i < menuImages.length; ++i) {
		menuImages[i].onmouseover = menuItemMouseOver;
		menuImages[i].onmouseout = menuItemMouseOut;
	}
}