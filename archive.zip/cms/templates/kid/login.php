	<div id="loginbar">
		<a href="./+login">Login</a> | <a href="./+login&subaction=register">Sign Up</a>
	</div>