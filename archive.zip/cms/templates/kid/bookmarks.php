<a href="http://del.icio.us/post?url=http://www.pragyan.org&amp;title=Pragyan : The International Technical Festival of NIT Trichy" alt="Add Pragyan.org to delicious" >
<img src="<?= $TEMPLATEBROWSERPATH ?>/../common/images/bookmarks/delicious.gif"></a>&nbsp;
<a href="http://digg.com/submit?phase=2&amp;url=http://www.pragyan.org&amp;title=Pragyan : The International Technical Festival of NIT Trichy" alt="Add Pragyan.org to digg" >
<img src="<?= $TEMPLATEBROWSERPATH ?>/../common/images/bookmarks/digg.gif"></a>&nbsp;
<a href="http://reddit.com/submit?url=http://www.pragyan.org&amp;title=Pragyan : The International Technical Festival of NIT Trichy" alt="Add Pragyan.org to reddit" >
<img src="<?= $TEMPLATEBROWSERPATH ?>/../common/images/bookmarks/reddit.gif"></a>&nbsp;
<a href="http://www.furl.net/storeIt.jsp?u=http://www.pragyan.org&amp;t=Pragyan : The International Technical Festival of NIT Trichy" alt="Add Pragyan.org to furl" >
<img src="<?= $TEMPLATEBROWSERPATH ?>/../common/images/bookmarks/furl.gif"></a>&nbsp;
<a href="http://www.google.com/bookmarks/mark?op=edit&amp;bkmk=http://www.pragyan.org&amp;title=Pragyan : The International Technical Festival of NIT Trichy">
<img src="<?= $TEMPLATEBROWSERPATH ?>/../common/images/bookmarks/google.png"></a>&nbsp;
<a href="http://www.facebook.com/sharer.php?u=http://www.pragyan.org&t=Pragyan : The International Technical Festival of NIT Trichy">
<img src="<?= $TEMPLATEBROWSERPATH ?>/../common/images/bookmarks/facebook.gif"></a>&nbsp;
<a href="http://www.stumbleupon.com/submit?url=http://www.pragyan.org&amp;title=Pragyan : The International Technical Festival of NIT Trichy">
<img src="<?= $TEMPLATEBROWSERPATH ?>/../common/images/bookmarks/stumbleupon.gif"></a>&nbsp;