<?php
/*
 * Created on Dec 6, 2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
 ?>
 <!--	<a href="http://www.addthis.com/bookmark.php" onclick="addthis_url = location.href; addthis_title = document.title; return addthis_click(this);" target="_blank" style="margin-right: 24px"><img src="<?= $TEMPLATEBROWSERPATH ?>/img/button1-bm.gif" width="125" height="16" border="0" alt="Bookmark this site" /></a><script type="text/javascript">var addthis_pub = 'Anshu';</script><script type="text/javascript" src="<?= $TEMPLATEBROWSERPATH ?>/js/addthis.js"></script>
				-->

