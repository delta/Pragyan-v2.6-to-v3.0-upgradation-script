<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Share Pragyan.org with your friends</title>
<script type="text/javascript">
function sets(val) {
  elt = document.getElementById('mys'); elt.value=val;
  elt = document.getElementById('winname'); elt.value=window.name;
  elt = document.getElementById('myform'); elt.submit();
}
</script>
</head>
<body>
<form id="myform" action="bookmark.php" method="post">
<input type="hidden" id="ate" name="ate" value="AT-internal/-/-/-/-/-" />
<input type="hidden" id="mys" name="s" value="" />
<input type="hidden" id="pub" name="pub" value="" />
<input type="hidden" id="url" name="url" value="" />
<input type="hidden" id="title" name="title" value="" />
<input type="hidden" id="lng" name="lng" value="" />
<input type="hidden" id="winname" name="winname" value="" />
<input type="hidden" id="content" name="content" value="" />
<div style="height:3px"></div>
<table width="600" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#666666">
  <tr>
    <td align="center">
	  <table width="100%" border="0" cellpadding="10" cellspacing="1">
        <tr>
          <td colspan="2" align="left" bgcolor="#FFFFFF">
		    <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr>   <td><span style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px; color: #373737">Bookmark &amp; Share</span></td>   <td align="right"><a href="http://www.addthis.com" target="_blank" ><img src="/images/addthis-logo-tiny.gif" width="128" height="15" border="0" alt="" /></a></td></tr></table></td>
              </tr>
              <tr>
                <td  align="left" bgcolor="#FFFFFF" class="style68" style="padding: 3px">
                  <br />Select a Service:<br />
                  <br /><table width="100%" border="0" cellpadding="3" cellspacing="0">
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('ask');" class="c1a" onclick="return omc('ask')"><span class="at15t at15t_ask">&nbsp;Ask</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('furl');" class="c1a" onclick="return omc('furl')"><span class="at15t at15t_furl">&nbsp;Furl</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('reddit');" class="c1a" onclick="return omc('reddit')"><span class="at15t at15t_reddit">&nbsp;Reddit</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('backflip');" class="c1a" onclick="return omc('backflip')"><span class="at15t at15t_backflip">&nbsp;Backflip</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('google');" class="c1a" onclick="return omc('google')"><span class="at15t at15t_google">&nbsp;Google Bookmarks</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('segnalo');" class="c1a" onclick="return omc('segnalo')"><span class="at15t at15t_segnalo">&nbsp;Segnalo</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('ballhype');" class="c1a" onclick="return omc('ballhype')"><span class="at15t at15t_ballhype">&nbsp;BallHype</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('kaboodle');" class="c1a" onclick="return omc('kaboodle')"><span class="at15t at15t_kaboodle">&nbsp;Kaboodle</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('simpy');" class="c1a" onclick="return omc('simpy')"><span class="at15t at15t_simpy">&nbsp;Simpy</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('bebo');" class="c1a" onclick="return omc('bebo')"><span class="at15t at15t_bebo">&nbsp;Bebo</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('linkagogo');" class="c1a" onclick="return omc('linkagogo')"><span class="at15t at15t_linkagogo">&nbsp;Link-a-Gogo</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('slashdot');" class="c1a" onclick="return omc('slashdot')"><span class="at15t at15t_slashdot">&nbsp;Slashdot</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('blinklist');" class="c1a" onclick="return omc('blinklist')"><span class="at15t at15t_blinklist">&nbsp;Blinklist</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('linkedin');" class="c1a" onclick="return omc('linkedin')"><span class="at15t at15t_linkedin">&nbsp;LinkedIn</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('spurl');" class="c1a" onclick="return omc('spurl')"><span class="at15t at15t_spurl">&nbsp;Spurl</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('blogmarks');" class="c1a" onclick="return omc('blogmarks')"><span class="at15t at15t_blogmarks">&nbsp;Blogmarks</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('live');" class="c1a" onclick="return omc('live')"><span class="at15t at15t_live">&nbsp;Live</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('stumbleupon');" class="c1a" onclick="return omc('stumbleupon')"><span class="at15t at15t_stumbleupon">&nbsp;StumbleUpon</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('delicious');" class="c1a" onclick="return omc('delicious')"><span class="at15t at15t_delicious">&nbsp;Delicious</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('magnolia');" class="c1a" onclick="return omc('magnolia')"><span class="at15t at15t_magnolia">&nbsp;Magnolia</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('tailrank');" class="c1a" onclick="return omc('tailrank')"><span class="at15t at15t_tailrank">&nbsp;Tailrank</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('digg');" class="c1a" onclick="return omc('digg')"><span class="at15t at15t_digg">&nbsp;Digg</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('misterwong');" class="c1a" onclick="return omc('misterwong')"><span class="at15t at15t_misterwong">&nbsp;Mister Wong</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('technorati');" class="c1a" onclick="return omc('technorati')"><span class="at15t at15t_technorati">&nbsp;Technorati</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('diigo');" class="c1a" onclick="return omc('diigo')"><span class="at15t at15t_diigo">&nbsp;Diigo</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('mixx');" class="c1a" onclick="return omc('mixx')"><span class="at15t at15t_mixx">&nbsp;Mixx</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('twitter');" class="c1a" onclick="return omc('twitter')"><span class="at15t at15t_twitter">&nbsp;Twitter</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('facebook');" class="c1a" onclick="return omc('facebook')"><span class="at15t at15t_facebook">&nbsp;Facebook</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('multiply');" class="c1a" onclick="return omc('multiply')"><span class="at15t at15t_multiply">&nbsp;Multiply</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('yahoobkm');" class="c1a" onclick="return omc('yahoobkm')"><span class="at15t at15t_yahoobkm">&nbsp;Yahoo Bookmarks</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('fark');" class="c1a" onclick="return omc('fark')"><span class="at15t at15t_fark">&nbsp;Fark</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('aolfav');" class="c1a" onclick="return omc('aolfav')"><span class="at15t at15t_aolfav">&nbsp;myAOL</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('buzz');" class="c1a" onclick="return omc('buzz')"><span class="at15t at15t_buzz">&nbsp;Yahoo Buzz</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('bluedot');" class="c1a" onclick="return omc('bluedot')"><span class="at15t at15t_bluedot">&nbsp;Faves (Bluedot)</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('myspace');" class="c1a" onclick="return omc('myspace')"><span class="at15t at15t_myspace">&nbsp;MySpace</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('myweb');" class="c1a" onclick="return omc('myweb')"><span class="at15t at15t_myweb">&nbsp;Yahoo MyWeb</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('favorites');" class="c1a" onclick="return omc('favorites')"><span class="at15t at15t_favorites">&nbsp;Favorites</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('netvouz');" class="c1a" onclick="return omc('netvouz')"><span class="at15t at15t_netvouz">&nbsp;Netvouz</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('yardbarker');" class="c1a" onclick="return omc('yardbarker')"><span class="at15t at15t_yardbarker">&nbsp;Yardbarker</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('feedmelinks');" class="c1a" onclick="return omc('feedmelinks')"><span class="at15t at15t_feedmelinks">&nbsp;FeedMeLinks</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('newsvine');" class="c1a" onclick="return omc('newsvine')"><span class="at15t at15t_newsvine">&nbsp;Newsvine</span></a></td>
<td width="10"></td><td class="c1"><a href="" class="c1a" onclick="return false"><span class="at15t at15t_more">&nbsp;</span></a></td>
</tr>
<tr>
<td width="10"></td><td class="c1"><a href="javascript:sets('friendfeed');" class="c1a" onclick="return omc('friendfeed')"><span class="at15t at15t_friendfeed">&nbsp;FriendFeed</span></a></td>
<td width="10"></td><td class="c1"><a href="javascript:sets('propeller');" class="c1a" onclick="return omc('propeller')"><span class="at15t at15t_propeller">&nbsp;Propeller</span></a></td>
<td width="10"></td><td class="c1"><a href="" class="c1a" onclick="return false"><span class="at15t at15t_more">&nbsp;</span></a></td>
</tr>
</table>
                  		  
                  <span>
                  <br />Get your own AddThis button!&nbsp;&nbsp;&nbsp;<a href="/" target="_blank"><img src="http://s7.addthis.com/button1-share.gif" width="125" height="16" border="0" align="absmiddle" alt="Get your button" /></a>
                  <br />       
                </td>
              </tr>
            </table>          
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table width="500" border="0" align="center" cellpadding="0" cellspacing="1">
  <tr>
    <td align="center"><span class="style78" style="font-size:6px">&copy; Copyright 2008 - <a href="/" target="_blank">AddThis.com</a></span></td>
  </tr>
</table>
</form>


</body>
</html>
