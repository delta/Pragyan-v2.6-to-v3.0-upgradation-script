<script type="text/javascript" charset="utf-8">
      $(document).ready(function() {        
        document.getElementById('partners').style.display = 'block';

        $('#partners').carousel({
          hide: 'fadeOut', 
          show: 'fadeIn', 
          duration: 500,
          speed: 2000, 
          seed: 5 
                  
        });
      });
    </script>

<div id="toplinks">



<ul>
<!--li><a href="/09/home/about_us" class="link2"><span>About Us</span></a></li-->
<li><a href="#" class="link8"></a></li>
<li><a href="/09/home/feedback" class="link5"><span>Suggestions</span></a></li>
<li><a href="/09/home/forum" class="link4"><span>Forum</span></a></li>
<!--li><a href="/09/home/contactus" class="link6"><span>Contact</span></a></li-->
<li><a href="http://www.pragyan.org/blog" target="_blank" class="link1"><span>Blog</span></a></li>
						</ul>
					</div>



<div class="partners">


<ul id="partners" style="display:none;position:relative;top:2px;">
<li><a href="http://www.intel.com" target="_blank"><img src="http://www.pragyan.org/09/home/partners/intel.jpeg"></a></li>
<li><a href="http://www.pcra.org" target="_blank"><img src="http://www.pragyan.org/09/home/downloads/pcras.jpg"></li>
<li><a href="http://www.mcafee.com" target="_blank"><img src="http://www.pragyan.org/09/home/partners/mcafee.jpg"></a></li>
<li><a href="http://www.trecstep.com" target="_blank"><img src="http://www.pragyan.org/09/home/downloads/trecstep.jpg"></a></li>
<li><a href="http://www.btechguru.com" target="_blank"><img src="http://www.pragyan.org/09/home/downloads/btechgurus.gif"></a></li>
<li><a href="http://www.expressbuzz.com" target="_blank"><img src="http://www.pragyan.org/09/home/partners/iexpresss.jpg"></a></li>
<li><a href="http://www.dsnglobal.com" target="_blank"><img src="http://www.pragyan.org/09/home/partners/dsn.jpg"></a></li>
<li><a href="http://www.zoho.com" target="_blank"><img src="http://www.pragyan.org/09/home/partners/zohos.jpg"></a></li>
<li><a href="http://www.forensicallychallenged.com" target="_blank"><img src="http://www.pragyan.org/09/home/partners/forensics.jpg"></a></li>
<li><a href="http://www.robosapiens-india.com" target="_blank"><img src="http://www.pragyan.org/09/home/downloads/robosapiens.jpg"></a></li>
<li><a href="http://www.sun.com" target="_blank"><img src="http://www.pragyan.org/09/home/downloads/sun_logos.jpg"></a></li>
<li><a href="http://www.nfindia.org" target="_blank"><img src="http://www.pragyan.org/09/home/downloads/nature.jpg"></a></li>
<li><a href="http://www.mindtree.com" target="_blank"><img src="http://www.pragyan.org/09/home/partners/mindtrees.gif"></a></li>
<li><a href="http://www.newscientist.com" target="_blank"><img src="http://www.pragyan.org/09/home/downloads/new_scientist.jpg"></a></li>
<li><a href="http://www.futuregroup.in" target="_blank"><img src="http://www.pragyan.org/09/home/partners/futures.jpg"></a></li>
<li><a href="http://www.myntra.com" target="_blank"><img src="http://www.pragyan.org/09/home/downloads/myntras.jpg"></a></li>
<li><a href="http://www.dst.gov.in" target="_blank"><img src="http://www.pragyan.org/09/home/partners/dsts.jpg"></a></li>
<li><a href="http://www.pagalguy.com" target="_blank"><img src="http://www.pragyan.org/09/home/partners/pagalguys.jpg"></a></li>
<li><a href="http://www.thinkdigit.com/"><img src="http://www.pragyan.org/09/home/partners/digitmag.jpg"></a></li>
<li><a href="http://www.kagazkaar.com" target="_blank"><img src="http://www.pragyan.org/09/home/partners/kagazkaar.jpg"></a></li>
</ul>


</div>

<div class="associatePartner">
<a href="#" class="link8"></a>
</div>