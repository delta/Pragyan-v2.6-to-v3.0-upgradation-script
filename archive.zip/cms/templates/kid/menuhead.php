<div id="topmenubar" class="mattblackmenu">
					<ul>
					<?php

					$menuHeads=array(
							'Events' => 'events',
							'Guest Lectures' => 'guestlectures',
							'Workshops' => 'workshops',
							'Infotainment'=>'infotainment',
							'Panel Discussion'=>'paneldiscussion',
							'Partners' => 'partners',
							'Links' => 'links',
							'Hospitality' => 'hospitality'
					);
					foreach ($menuHeads as $menuHead => $menuHref) {
						echo '<li><a href="/09/home/' . $menuHref . '" rel="'.$menuHead.'">'.$menuHead.'</a></li>';
					}
					$remote = $_SERVER['REMOTE_ADDR'];
			if(!(strpos($remote,'10.')===0))
				include_once("searchbox.php");
					?>						
				
			</ul>
				</div>
				<script type="text/javascript">
					ddlevelsmenu.setup("topmenubar", "topbar") //ddlevelsmenu.setup("mainmenuid", "topbar|sidebar")
				</script>


