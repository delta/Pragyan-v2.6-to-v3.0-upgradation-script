    <script type="text/javascript">
       var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + "http://www.pragyan.org/09/cms/templates/kid/js/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
  try {
  var pageTracker = _gat._getTracker("UA-6489361-1");
  pageTracker._trackPageview();
} catch(err) {}</script>
		<script type="text/javascript" src="<?= $TEMPLATEBROWSERPATH ?>/js/brand.js"></script><div id="results_013069423422863237431:u9nytclvrk4" style="display:none"><div class="cse-closeResults"><a>&times; Close</a></div><div class="cse-resultsContainer"></div></div><style type="text/css">
@import url(<?= $TEMPLATEBROWSERPATH ?>/css/overlay.css);
</style><script src="<?= $TEMPLATEBROWSERPATH ?>/js/api.js" type="text/javascript"></script><script src="<?= $TEMPLATEBROWSERPATH ?>/js/overlay.js" type="text/javascript"></script>
<script type="text/javascript">
function OnLoad() {
  new CSEOverlay("013069423422863237431:u9nytclvrk4",
                 document.getElementById("searchbox_013069423422863237431:u9nytclvrk4"),
                 document.getElementById("results_013069423422863237431:u9nytclvrk4"));
}
GSearch.setOnLoadCallback(OnLoad);
</script>