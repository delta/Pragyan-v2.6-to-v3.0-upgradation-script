	<!--
			DROP DOWN MENU INNER ITEMS
			THESE ELEMENTS MUST BE OUTSIDE ALL TAGS EXCEPT BODY
		-->
		<?php 
		$menuHeads = array('Events','Guest Lectures','Workshops');
		$path = array('events','guestlectures','workshops');
		//$menuHeadsPageIds is hardcoded for the time being.
		$menuHeadsPageIds = array(860,861,862);
		
		foreach($menuHeads as $pos => $value) {
			$level1path = $path[$pos];
			echo '<ul id="'.$value.'" class="ddsubmenustyle">';
			$level = 1;
			$query = "select `page_id`, `page_title`, `page_name` from pragyanV2_pages where page_parentid=$menuHeadsPageIds[$pos]";
			$result = mysql_query($query);
			while ($children = mysql_fetch_row($result)) {
				echo '<li><a href="/09/home/'.$level1path.'/'.$children[2].'">'.$children[1].'</a>';
				{
					$query1 = "select `page_id`, `page_title`,`page_name` from pragyanV2_pages where page_parentid=$children[0]";
					$result1 = mysql_query($query1);
					if (mysql_num_rows($result1)) {
					echo '<ul>';
					while ($children1 = mysql_fetch_row($result1)) {
					echo '<li><a href="/09/home/'.$level1path.'/'.$children[2].'/'.$children1[2].'">'.$children1[1].'</a></li>';
					}
					echo'</ul></li>';
					}
					else echo '</li>';
			}
		}
			echo '</ul>';}
