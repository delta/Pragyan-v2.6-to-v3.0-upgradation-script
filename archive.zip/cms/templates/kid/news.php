<script type="text/javascript">new pausescroller(pausecontent2, "pscroller2", "someclass", 4000)</script>
<div id="pscroller2" class="someclass" style="overflow: hidden; position: relative; display:none;">
<div class="innerDiv"  id="pscroller21"></div>
<div class="innerDiv" id="pscroller22"></div>
</div>
