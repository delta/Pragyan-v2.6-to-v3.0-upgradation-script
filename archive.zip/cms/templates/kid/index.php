<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<title><?= strip_tags($TITLE) ?></title>
		<meta name="DC.description" content="Pragyan 2009 : The International Technical Festival of NIT Trichy" />
		<meta name="DC.creator" content="Pragyan 2009 Team" />
		<meta name="DC.subject" content="Pragyan,Technical,Festival,India,Tamil Nadu,NIT,Trichy,Bytecode" />
		<meta name="DC.format" content="text/html; charset=UTF-8" />
		<meta name="y_key" content="457cae25fb9ebeed" />
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<?
global $urlRequestRoot;    
global $PAGELASTUPDATED;
if($PAGELASTUPDATED!=""){
  echo '<meta http-equiv="Last-Update" content="'.substr($PAGELASTUPDATED,0,10).'" />'."\n";
 }        ?>
		<meta name="keywords" content="pragyan, 2009, 09, techfest, technical festival, festival, trichy, tiruchi, nitt, NITT, National Institute of Technology, Tituchirappalli, robovigyan, events, robotics" /><meta name="description" content="Pragyan, the annual international technical festival of National Institute of Techonlgy, Tiruchirappalli" />
		<link rel="alternate" type="application/rss+xml" title="Pragyan 09 RSS feed" href="/09/home/news/+rssview" />
		<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
		<link rel="stylesheet" href="<?= $TEMPLATEBROWSERPATH?>/css/main.2588.css" type="text/css" />
		 <?
			if ($MENUBAR == '')
				echo "<link rel=\"stylesheet\" href=\"$TEMPLATEBROWSERPATH/css/nomenu.css\" />\n";
		?>
		<script type="text/javascript">
		<!--
			TEMPLATE_PATH = '<?= $TEMPLATEBROWSERPATH ?>';
		-->
		</script>
		<script type="text/javascript" src="<?= $TEMPLATEBROWSERPATH?>/js/all.js"></script>
		<script type="text/javascript" src="<?= $TEMPLATEBROWSERPATH?>/js/news1.js"></script>
		<script type="text/javascript" src="<?= $TEMPLATEBROWSERPATH?>/js/partners.js"></script>
	</head>
	<body>
		 <?
//   			}
   			global $userId,$pageId;
   			$pageModule = getEffectivePageModule($pageId);
		?>
		<div id="outerwrapper">
			<div id="wrapper">
				<div id="header">
					<div id="logo">
						<a href="/09/home/"><img src="<?= $TEMPLATEBROWSERPATH ?>/img/pragyan2.gif" alt="Pragyan 2009" /></a>
					</div>
					<?
					include_once("toplinks.php");
					?>
				</div>
		 <?
				include_once("menuhead.php");
		?>
<div id="newsbar">
<? 
	require_once("$sourceFolder/$moduleFolder/news/news.kid.php");
	echo displayNew();
	require_once("news.php");
?>
<div id="defaultCountdown" class="countdown" align="right" ></div>
<script type="text/javascript">
	  var pragyan = new Date(2009, 1, 12,18,0); 
$('#defaultCountdown').countdown({until: pragyan});
</script>&nbsp;
</div>				

				<div id="breadcrumbs">
					<?= $BREADCRUMB ?>
					<?=(($userId==0)?"":$ACTIONBARPAGE)?>
					<?=(($userId==0)?"":$ACTIONBARMODULE)?>
			                 <?
 if($userId==0) {
			  echo '<div id="cms-actionbarPage"><span class="cms-actionbarPageItem" style="border-right:1px dotted;" ><a class="robots-nofollow" rel="nofollow" href="./+login">Login</a></span><span class="cms-actionbarPageItem"><a class="robots-nofollow" rel="nofollow" href="./+login&subaction=register">Register</a></span></div>';
} ?>
					<div class="clearer"></div>
				</div>
				<div id="contentwrapper">
					<div id="contentcolumn">
						<div class="contentinnertube">
							<?=$INFOSTRING?>
		          			<?=$WARNINGSTRING?>
		          			<?=$ERRORSTRING?>
		          			<?
		          				$head = substr($TITLE, 13);
		          				if ($head!='Home') {
		          					echo '<h1 id="contentHeader">' . $head . '</h1>'; 
		          				}
		          			?>
		          			<div class="clearer"></div>
		          			<?=$CONTENT?>
		          			<div class="clearer"></div>
						</div>
					</div>
				</div>
			 <?
				if ($MENUBAR != '') {
			?>
				<div id="leftcolumn">
					<div class="innertube">
						<?= $MENUBAR ?>
						<script type="text/javascript">
							setupMenubar();
						</script>
					</div>
				</div>
			 <?
				}
			?>
				<div class="clearer"></div>
				<div id="footer" style="vertical-align: middle">
					<span style="float: left; margin: auto 12px;"><a href="/09/home/news/+rssview"><img src="<?= $TEMPLATEBROWSERPATH?>/img/rss.png" alt="RSS Feeds" /></a></span>
							  <span style="float: left; color: white; margin: auto 12px"><a href="/09/home/contactus">Contact Us</a> | <a href="http://www.nitt.edu" target="_blank">NIT Trichy</a> | <a href="/09/home/sitemap">Sitemap</a></span>
					<span style="float: right"><a href="http://www.mozilla.com/en-US/firefox/" target="_blank">Site optimized for
					<img src="<?= $TEMPLATEBROWSERPATH ?>/img/ff.png"></a>
					<? include_once("bookmarks.php"); ?>
					</span>
				</div>
			</div> <!-- wrapper -->
		</div> <!-- outerwrapper -->
		<div id="copyright" style="height:50px">
			&copy; 2009 Team Pragyan, National Institute Of Technology, Tiruchirappalli. All Rights Reserved.
		</div>
<?
include_once("menulist.php");
?>
		<script type="text/javascript">
			if (document.getElementById('tabbedcontent')){
				tabbedContent(document.getElementById('tabbedcontent'));
				document.getElementById('tabvisiblecontent').innerHTML = document.getElementById('tabcontent1').innerHTML;
				if (curSelected != -1)
					document.getElementById('tabheading' + curSelected).className = 'tabheading';
				curSelected = 1;
				document.getElementById('tabheading' + curSelected).className = 'tabheading selectedtab';
			}
		</script>
 <?
		$remote = $_SERVER['REMOTE_ADDR'];
if(!(strpos($remote,'10.')===0))
		include_once("analytics.php");
			global $pageId;
   			$pageModule = getEffectivePageModule($pageId);
   			if($pageModule!='form') {
	?>
			<div id="news-footer" class="newsFooter"><span style="float: left; margin-left:12px;"><a href="/09/home/news/+rssview"><img src="<?= $TEMPLATEBROWSERPATH?>/img/rss.png" alt="RSS Feeds" /></a></span><div class="newsUpdate"><a href="/09/home/news/" style="color:#f9dc72"><strong>NEWS UPDATE::</strong></a></div><div class="newsBox" ><ul id="newsListElement" style="display:none">
			<? 
	require_once("$sourceFolder/$moduleFolder/news/news.kid.php");
	echo displayNews();
?></ul></div><!--newsBox-->
		</div><!--newsUpdate-->
			</div><!--newsFooter-->
			<?
   			}
			?>
			<script>
$(function() {
	document.getElementById('newsListElement').style.display = 'block';
    $(".newsBox").jCarouselLite({
        btnNext: ".next",
        btnPrev: ".prev",
	auto: 2500,
	speed: 200
    });
});
</script>
<style type="text/css">
	div#news-footer {
		position:fixed;
		_top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (documentElement.clientHeight-this.clientHeight) : document.body.scrollTop + (document.body.clientHeight-this.clientHeight));
		_position:absolute;
		overflow:hidden;
	}
	div.newsFooter{
		width:100%;
	}
	</style>
	</body>
</html>
