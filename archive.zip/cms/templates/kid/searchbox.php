	<div id="srch" align="right">
			<form action="" id="searchbox_013069423422863237431:u9nytclvrk4" onsubmit="return false;">
				<div>
					<input type="text" name="q" size="10" style="height:12px; margin-top:4px;" />
					<input type="image"  src="<?=  $TEMPLATEBROWSERPATH?>/img/SearchBt.png	"/>
				</div>
			</form>
		</div><!--/srch-->
		