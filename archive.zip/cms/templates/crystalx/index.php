<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title><?= $TITLE ?></title>
    <meta name="description" content="The official website of the Rotaract Club of NIT Trichy" />
    <meta name="keywords" content="Rotaract Club, National Institute of Technology, Tiruchirappalli, Trichy" />
	<?global $urlRequestRoot;	global $PAGELASTUPDATED;
	if($PAGELASTUPDATED!="")
		echo '<meta http-equiv="Last-Update" content="'.substr($PAGELASTUPDATED,0,10).'" />'."\n";
	?>
    <link rel="index" href="./" title="Home" />
    <link rel="stylesheet" media="screen,projection" type="text/css" href="<?= $TEMPLATEBROWSERPATH ?>/css/main.css" />
    <link rel="stylesheet" media="print" type="text/css" href="<?= $TEMPLATEBROWSERPATH ?>/css/print.css" />
    <link rel="stylesheet" media="aural" type="text/css" href="<?= $TEMPLATEBROWSERPATH ?>/css/aural.css" />
    <link rel="stylesheet" type="text/css" href="<?= $TEMPLATEBROWSERPATH ?>/css/other.css" />
    <link rel="stylesheet" type="text/css" href="<?= $TEMPLATEBROWSERPATH ?>/../common/error.css" />

	<script language="javascript" type="text/javascript">
		//defined here for use in javascript
		var templateBrowserPath = "<?=$TEMPLATEBROWSERPATH ?>";
		var urlRequestRoot = "<?=$urlRequestRoot?>";
	</script>
</head>

<body>

<!-- Main -->
<div id="main" class="box">

    <!-- Header -->
    <div id="header">
        <!-- Logotyp -->
        <h1 id="logo"><a href="http://pragyan.org" title="Praygan CMS">Pragyan CMS</a></h1>
    </div> <!-- /header -->

    <!-- Page (2 columns) -->
    <div id="page" class="box">
    <div id="page-in" class="box">
        <div id="strip" class="box noprint">
            <!-- Breadcrumbs -->
            <div id="breadcrumbs">
	           	<?= $BREADCRUMB ?>
	           	<?php
	           		global $userId;
	           		if($userId == 0) {
	           			echo "<div id=\"cms-actionbarPage\"><span class=\"cms-actionbarPageItem\"><a href=\"./+login\">Login</a></span></div>";
	           		}
	           	?>
				<?=(($userId==0)?"":$ACTIONBARPAGE)?>
				<?=(($userId==0)?"":$ACTIONBARMODULE)?>
            </div>
            <hr class="noscreen" />
            
        </div> <!-- /strip -->

        <!-- Content -->
        <div id="content">

            <!-- Article -->
            <div class="article">
              <?=$INFOSTRING?>
	          <?=$WARNINGSTRING?>
	          <?=$ERRORSTRING?>
	          <?= $CONTENT ?>
            </div> <!-- /article -->
        </div> <!-- /content -->

        <!-- Right column -->
        <div id="col" class="noprint">
            <div id="col-in">
                <!-- Category -->
				<?=$MENUBAR?>

				<hr class="noscreen" />
				<h3><span>Links</span></h3>
				<ul id="links">
					<li><a href="http://pragyan.org">Other Links</a></li>
				</ul>
				<hr class="noscreen"/>
            </div> <!-- /col-in -->
        </div> <!-- /col -->
    </div> <!-- /page-in -->
    </div> <!-- /page -->

    <!-- Footer -->
    <div id="footer">
        <div id="top" class="noprint"><p><span class="noscreen">Back to top</span> <a href="#header" title="Back to top ^">^<span></span></a></p></div>
        <hr class="noscreen" />
        <p id="copyright">&copy; 2008 <a href="mailto:admin@pragyan.org">Pragyan CMS</a></p>
    </div> <!-- /footer -->

</div> <!-- /main -->

</body>
</html>
