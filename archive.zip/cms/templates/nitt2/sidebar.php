<?
global $SIDEBARCONTENT;
$date = date("D d M y, h:ia");
$date .= " IST";
$SIDEBARCONTENT = '<div id="sidebardate">'.$date.'</div>
		<div class="quicklinks">
				<h6>Quick Links</h6>				
				<ul>
					<li><a>TEQIP</a></li>

					<li><a>Connect NIT</a></li>
					<li>Facilities And Services</li>
				      	<li>Departments</li>
				      	<li>Visiting Proffesors Under TEQIP</li>
					<li>Achievements</li>
				</ul>

			</div>
			<div class="quicklinks">
				<h6>Events @ NITT</h6>				
				<ul>
					<li>TEQIP</li>
					<li>Connect NIT</li>
					<li>Facilities And Services</li>

				      	<li>Departments</li>
				      	<li>Visiting Proffesors Under TEQIP</li>
					<li>Achievements</li>
				</ul>
			</div>

';
		

