<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?



$menu_left = $MENUBAR;
include_once("$TEMPLATECODEPATH/sidebar.php");global $pageId;
$menu_right = "";
if($pageId==0)
	$menu_right = $SIDEBARCONTENT;
$extracss="";

if($menu_left != "" && $menu_right != "")
	$extracss = "leftAndRightMenu.css";
elseif($menu_left != "" && $menu_right == "")
	$extracss = "leftMenuOnly.css";
elseif($menu_left == "" && $menu_right != "")
	$extracss = "rightMenuOnly.css";
else
	$extracss = "noMenu.css";
?>




<html>
<head>
	<title><?= $TITLE ?></title>
	<link rel="stylesheet" href="<?= $TEMPLATEBROWSERPATH ?>/style.css" />
	<link rel="stylesheet" href="<?= $TEMPLATEBROWSERPATH ?>/<?=$extracss?>" />
	<link rel="stylesheet" href="<?= $TEMPLATEBROWSERPATH ?>/../common/error.css" />
</head>
<body>
	
	<div id="outer_wrapper">

		<div id="topbox_wrapper">

			<div id="header_wrapper">
				<div id="header_content">
					<a  href="<?= $urlRequestRoot?>">
						<img alt="NIT Trichy" src="<?= $TEMPLATEBROWSERPATH ?>/images/nitt-logo-white.png"/>
						<h1>National Institute of Technology</h1>
						<h2>Tiruchirapalli</h2>
					</a>
				</div><!--header_content-->
			</div><!--header_wrapper-->

			<div id="toplinkbar_wrapper">
				<div id="toplinkbar_content">
					<div><div class="toplinkinner"><a href="<?= $urlRequestRoot?>" title="Home">
<img alt="To start page" src="<?= $TEMPLATEBROWSERPATH ?>/images/home_button.png" />
</a></div></div>
					<div><div class="toplinkinner"><a class="toplink" href="http://www.bth.se/eng/education/">Education</a></div></div>
					<div><div class="toplinkinner"><a class="toplink" href="http://www.bth.se/eng/research/">Research</a></div></div>
					<div><div class="toplinkinner"><a class="toplink" href="http://www.bth.se/eng/collaboration/">Collaboration</a></div></div>

				</div><!--toplinkbar_content-->
			</div><!--toplinkbar_wraper-->

		</div><!--topbox_wrapper-->

		<div id="content_wrapper"><!--the whole page from left to right-->
			<div id="content_outercontainer">
				<div id="content_containerleftborder"><!-- having the left border -->
					<div id="content_containerrightborder"><!-- having the right border -->
						<div id="content_container"><!--content within the borders, including menus and footer--> 
							<div id="menu_left">
								<?= $menu_left ?>
							</div><!--menu_left-->
							<div id="menu_right">
								<?= $menu_right ?>
							</div><!--menu_right-->
							<div id="content_main">
								<table id="breadcrumbtable" cellpadding="0" cellspacing="0" width="100%">
									<tr>
										<td><?=$BREADCRUMB?></td>
										<td align="right"><?=$ACTIONBARPAGE?><?=$ACTIONBARMODULE?></td>
									</tr>
								</table>
								
								<div id="content">
									<?=$ERRORSTRING?>
	        						<?=$INFOSTRING?>
	        						<?=$WARNINGSTRING?>
									<?=$CONTENT?>
								</div><!--content-->
							</div><!--content_main-->
							<div id="footer">
								<strong>

				<a href="contact.html">Contact NITT</a> | <a href="http://">Right to Information Act</a> | <a href="disclaimer.html">Disclaimer</a> | <a href="privacy.html">Privacy</a> | <a href="webteam.html">Webteam</a> | <a href="aboutsite.html">About This Site</a>

			</strong>
			<br />
			Copyright <a href="copyright.html">&copy;</a> 2008 Webteam @ NIT Trichy<br />
		 	National Institute of Technology, Tiruchirapalli - 620015, INDIA <br />
			Phone No: | Fax No:

							</div><!--footer-->
						</div><!--content_container-->
					</div><!--content_containerrightborder-->
				</div><!--content_containerleftborder-->
			</div><!--content_outercontainer-->
		</div><!--content_wrapper-->
	</div><!-- /outer_wrapper -->
</body>
</html>
