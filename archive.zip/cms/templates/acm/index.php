
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title><?= $TITLE ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Language" content="en-us" />
<META http-equiv=Page-Enter content=blendTrans(Duration=1.0)><!--increase the duration to enhance the effect-->
<META http-equiv=Page-Exit content=blendTrans(Duration=1.0)><!--increase the duration to enhance the effect-->
<link href="<?= $TEMPLATEBROWSERPATH ?>/images/style_3c.css" type="text/css" rel="stylesheet">
<script language="javascript" type="text/javascript">
  <!--
  //  window.onload = function() {
  //    AddFillerLink("header", "left", "main", "sidebar", "footer");
  //  }
  -->
  </script>
  <script language="javascript" type="text/javascript">
  	function loadScript() {
  		<?= $STARTSCRIPTS ?>
  	}
  </script>
</head>
<body onload="loadScript()">
<div class="content">
<div id="toph"></div>
<div id="header">
<div id="header_main">
<ul id="menu">
<li>
<a href="#" onclick="showComment('home.php')" title="">Home</a>
<li>
<a href="#" onclick="showComment('catalogue.php')" title="">Catalogue</a>
<li>
<a href="#" onclick="showComment('pub.php')" title="">Services</a>
<li>
<a href="gallery.php" title="">Gallery</a>
<li>
<a href="#" onclick="showComment('contacts.php')" title="">Contacts</a></li>
</ul>
<form id="search" method="get" action="http://www.google.com/search">
<fieldset>
<input type=hidden name=ie value=UTF-8>
<input type=hidden name=oe value=UTF-8>
<input type=hidden name=domains value="presidentialchoice.com">
<input type=hidden name=sitesearch value="presidentialchoice.com">
<INPUT id="input1" class=inputbox
onblur="if(this.value=='') this.value='Search this site...';"
onfocus="if(this.value=='Search this site...') this.value='';"
alt=search value="Search this site..." name=q>
<input name="input2" type="submit" id="input2" value="Search">
</fieldset>
</form>

</div>
<div class="rside"><div class="citation"></div></div>
<div class="breadcrumbbar">
    <?=$BREADCRUMB?>
	<?=$ACTIONBARPAGE?>
	<?=$ACTIONBARMODULE?>
</div>
</div>
<div id="main">
<div class="leftmenu">
<div class="padding">
<h2 align="center">Login</h2>
<TABLE class="leftmenu1" cellSpacing="0" cellPadding="0">
<TBODY>
<TR>
<TD>
<FORM name="login" action="./index.php?option=login" method="post">
<TABLE cellSpacing="1" cellPadding="0" align="center" border="0">
<TBODY>
<TR>
<TD><div align="center"><strong>Username</strong><BR>
<INPUT size="10" name="username">
<BR>
<strong>Password</strong><BR>
<INPUT type="password" size="10" name="passwd">
<BR>
<BR>
<input name="input2" type="submit" id="input2" value="Submit">
<BR>
<INPUT type='checkbox' name='remember_me' value='y'> <strong><small>Remember Me</small></strong>
<BR>
<a href="../forgetpasswd.php"><small>Forgot Password?</small></a>
</div>
</TD>
</TR>
</TBODY></TABLE>
</FORM>
</TD>
</TR>
</TBODY></TABLE>
<!--Register Table Begins Here-->
<TABLE cellSpacing="0" cellPadding="1" border="0" class="leftmenu1">
<TBODY>
<TR>
<TD><b>Not yet Registered?<br>
click <a href="#" onClick="showComment('register_form.php')">here </a>to register</b></TD>
</TR>
</TBODY></TABLE>
<br>
<hr>
<div class="padding">
<h2 align="center">Newsletter</h2>
<form action="./subscribe.php" method="post">
<div class="search">
<input type="text" onblur="if(this.value=='') this.value='Enter e-mail';"
onfocus="if(this.value=='Enter e-mail') this.value='';"
alt=E-mail value="Enter e-mail" class="text" name="address" id="address"/>
<input type="submit" value="Go" class="searchbutton"><br>
</div>
</form>
</div>
<div class="boxads"><h2>Member Stats</h2>
<ul>
<li>Online Members</li>
<li>Registered Members</li>
<li>Newest Members</li>
</ul>
<br /><br /><br /><br /></div>
<h2>&nbsp;</h2>
</div>
</div>
<div class="center" id="india">

  <?=$ERRORSTRING?>
  <?=$INFOSTRING?>
  <?=$WARNINGSTRING?>
  <?=$CONTENT?>



</div>
<div class="right_side">

<?=$MENUBAR?>

</div>
</div>
<br>
&nbsp;<br>
<div id="footer">Copyright &copy; PRAGYAN CMS </div>
</div>
</body>
</html>
