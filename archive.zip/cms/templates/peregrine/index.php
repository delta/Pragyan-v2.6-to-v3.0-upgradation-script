<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?=$TITLE?></title>
<meta name="keywords" content="pragyan, 2009, 09, techfest, technical festival, festival, trichy, tiruchi, nitt, NITT, National Institute of Technology, Tituchirappalli, robovigyan, events, robotics" /><meta name="description" content="Pragyan, the annual international technical festival of National Institute of Techonlgy, Tiruchirappalli" />
<link rel="alternate" type="application/rss+xml" title="Pragyan 09 RSS feed" href="" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="<?= $TEMPLATEBROWSERPATH ?>/css/main.css" media="screen,projection,print,tv" />
<link rel="stylesheet" type="text/css" href="<?= $TEMPLATEBROWSERPATH ?>/css/header.css" media="screen,projection,print,tv" />
<style type="text/css"><!--
	#content {
		padding:0px;
	}
-->
</style>
</head>
<body>
<div id="wrap1">
	<div id="wrap2">
		<div id="wrap3">
			<div id="top">
				<p class="hide">
					<a href="index.html#contentstart">Skip navigation</a>.
				</p>
				<div id="top">
	<div id="top3">
		<div id="srch">
			<form action="" id="searchbox_013069423422863237431:u9nytclvrk4" onsubmit="return false;">
				<div>
					<input type="text" name="q" />
					<input type="submit" value="Search"/>
				</div>
			</form>
		</div><!--/srch-->
 		<h1 id="logo">
	 		<a href="/">
	 		<img src="<?= $TEMPLATEBROWSERPATH ?>/img/pragyan.png" alt="Pragyan logo"   height="53" width="165">
	 		</a>
 		</h1>
 		<? 
	global $userId;
	if($userId==0) {
	  include_once("login.php");
	}?>
	 </div><!--/top3-->
					 </div><!--top-->
			</div>
			<? include("pragyanmenu.php");?>
 			<div id="breadcrumbs">
	           	<?= $BREADCRUMB ?>
				<?=(($userId==0)?"":$ACTIONBARPAGE)?>
				<?=(($userId==0)?"":$ACTIONBARMODULE)?>
				</div>
            <? //include("breadcrumb.php");?>
            
            
            <hr class="noscreen" />
			<span class="clearer"></span>
			<div id="wrap4">
				<div id="content" class="fixed">
					<?=$INFOSTRING?>
          			<?=$WARNINGSTRING?>
          			<?=$ERRORSTRING?>
          			<div id="main">
          			<? $head = substr($TITLE,13); if($head!='Home') {?>
          			<h1 id="contentHeader"><? echo $head; ?>
          			</h1>
          			<?}?>
          			<?=$CONTENT?>
	        	</div>
		    <div id="side">
		    <?=$MENUBAR?>
            </div> <!-- /smenu -->
        </div> <!-- /menu -->
				</div>
			</div>
		</div>
	</div>
</div>

<div id="footer">
	<div id="footerbar">
		<span class="left">&copy; 2009 <a href="http://www.pragyan.org">Pragyan Team</a>. All Rights Reserved</span>

		<div class="right">
			<a href="<?= $urlRequestRoot?>/sitemap">Sitemap</a>
			<a href="/sitemap.xml" style="position:relative;padding-top:5px;"><img src="<?= $TEMPLATEBROWSERPATH?>/img/xml-small.png"></a>
		</div>
		<a class="right" href="http://nitt.edu">NIT Trichy</a>
		<a class="right" href="<?= $urlRequestRoot?>/contacts">Contacts</a>
		<a class="right" href="<?=$urlRequestRoot?>/news/+rssview"><img src="<?= $TEMPLATEBROWSERPATH?>/img/rss.png"></a>

		<span class="right" style="position:relative;left:-13px; margin-top: -4px">
			<a href="http://del.icio.us/post?url=<?=$BlogItemPermalinkURL?>&amp;title=<?=$BlogItemTitle?>" alt="Add Pragyan.org to delicious" >
			<img src="<?= $TEMPLATEBROWSERPATH?>/img/delicious.gif"></a>&nbsp;
			<a href="http://digg.com/submit?phase=2&amp;url=<?=$BlogItemPermalinkURL?>&amp;title=<?=$BlogItemTitle?>" alt="Add Pragyan.org to digg" >
			<img src="<?= $TEMPLATEBROWSERPATH?>/img/digg.gif"></a>&nbsp;
			<a href="http://reddit.com/submit?url=<?=$BlogItemPermalinkURL?>&amp;title=<?=$BlogItemTitle?>" alt="Add Pragyan.org to reddit" >
			<img src="<?= $TEMPLATEBROWSERPATH?>/img/reddit.gif"></a>&nbsp;
			<a href="http://www.furl.net/storeIt.jsp?u=<?=$BlogItemPermalinkURL?>&amp;t=<?=$BlogItemTitle?>" alt="Add Pragyan.org to furl" >
			<img src="<?= $TEMPLATEBROWSERPATH?>/img/furl.gif"></a>&nbsp;
			<a href="http://www.google.com/bookmarks/mark?op=edit&amp;bkmk=<?=$BlogItemPermalinkURL?>&amp;title=<?=$BlogItemTitle?>">
			<img src="<?= $TEMPLATEBROWSERPATH?>/img/google.png"></a>&nbsp;
			<a href="http://www.facebook.com/sharer.php?u=<?=$BlogItemPermalinkURL?>&t=<?=$BlogItemTitle?>">
			<img src="<?= $TEMPLATEBROWSERPATH?>/img/facebook.gif"></a>&nbsp;
			<a href="http://www.stumbleupon.com/submit?url=<?=$BlogItemPermalinkURL?>&amp;title=<?=$BlogItemTitle?>">
			<img src="<?= $TEMPLATEBROWSERPATH?>/img/stumbleupon.gif"></a>&nbsp;
		</div>
	</div>
<!--	<span class="left">&copy; 2008 <a href="http://www.pragyan.org">Pragyan Team</a>. All Rights Reserved</span>
-->
	<!--<div class="right" >Bookmark Us :</div>-->
</div>

<script type="text/javascript" src="<?= $TEMPLATEBROWSERPATH ?>/js/brand.js"></script><div id="results_013069423422863237431:u9nytclvrk4" style="display:none"><div class="cse-closeResults"><a>&times; Close</a></div><div class="cse-resultsContainer"></div></div><style type="text/css">
@import url(<?= $TEMPLATEBROWSERPATH ?>/css/overlay.css);
</style><script src="<?= $TEMPLATEBROWSERPATH ?>/js/api.js" type="text/javascript"></script><script src="<?= $TEMPLATEBROWSERPATH ?>/js/overlay.js" type="text/javascript"></script>
<script type="text/javascript">
function OnLoad() {
  new CSEOverlay("013069423422863237431:u9nytclvrk4",
                 document.getElementById("searchbox_013069423422863237431:u9nytclvrk4"),
                 document.getElementById("results_013069423422863237431:u9nytclvrk4"));
}
GSearch.setOnLoadCallback(OnLoad);
</script>


</body>


</html>
