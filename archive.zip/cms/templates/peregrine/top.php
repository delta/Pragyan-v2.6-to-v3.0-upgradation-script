<div id="top">
<div id="top3">
 <div id="srch">
						<form action="" id="searchbox_013069423422863237431:u9nytclvrk4" onsubmit="return false;">
							<div>
								<input type="text" name="q" />
								<input type="submit" value="Search"/>
							</div>
						</form>
					</div>
 <h1 id="logo"><a href="http://my.opera.com/"><img src="login_files/logo4.gif" alt="My Opera Community" class="hidemobile" height="53" width="165">
 <img src="login_files/logo-mobile.gif" alt="My Opera Community" class="mobile" height="19" width="129"></a></h1>
 <p id="mtabs" class="mobile">< a href="http://my.opera.com/community/">
 <img src="login_files/tab1b.gif" alt="explore" height="14" width="44"></a>
 <a href="http://my.opera.com/community/opera/">
 <img src="login_files/tab5a.gif" alt="opera" height="14" width="37"></a></p>
 <ul id="toplinx"><li id="explore" style="border: medium none ;" class="on">
 <a href="http://my.opera.com/community/" class="hidemobile droparrow"><span>Explore</span></a>
 <ul class="drop hidemobile">
 <li><a href="http://my.opera.com/community/" style="background-position: 6px 0px;">Home</a></li>
 <li><a href="http://my.opera.com/community/blogs/" style="background-position: 6px -23px;">Blogs</a></li>
 <li><a href="http://my.opera.com/community/albums/" style="background-position: 6px -48px;">Photos</a></li>
 <li><a href="http://my.opera.com/community/people/" style="background-position: 6px -96px;">Members</a></li>
 <li><a href="http://my.opera.com/community/forums/" style="background-position: 6px -72px;">Forums</a></li>
 <li><a href="http://my.opera.com/community/groups/" style="background-position: 6px -120px;">Groups</a></li></ul>
 </li>
 <li id="opera"><a href="http://my.opera.com/community/opera/" class="hidemobile droparrow"><span>Opera</span></a>
 <ul class="drop hidemobile"><li>
 <a href="http://my.opera.com/community/opera/" style="background-position: 6px -144px;">Opera for PC/Mac</a></li>
 <li><a href="http://my.opera.com/community/mobile/" style="background-position: 6px -168px;">Opera Mini</a></li>
 <li class="hidemobile"><a href="http://my.opera.com/community/customize/" style="background-position: 6px -216px;">Skins + Setups</a></li>
 <li class="hidemobile"><a href="http://my.opera.com/community/opera/wallpapers/" style="background-position: 6px -387px;">Wallpapers</a></li>
 <li><a href="http://my.opera.com/community/opera/buttons/" style="background-position: 6px -411px;">Buttons</a></li>
 <li><a href="http://my.opera.com/community/operastore/" style="background-position: 6px -364px;">Shop</a></li>
 <li><a href="http://my.opera.com/community/openweb/" style="background-position: 6px -216px;">Open the Web</a></li>
 <li><a href="http://my.opera.com/chooseopera/blog/" style="background-position: 6px -435px;">Choose Opera</a></li>
 </ul></li>
 <li class="hidemobile" id="login">
 <a href="./+login" onclick="document.getElementById('myo-login').className = 'show';document.getElementById('srch').className = 'hide';document.getElementById('username').focus();return false;">
	
					Log&nbsp;in</a></li>
					<li class="hidemobile"><a href="http://my.opera.com/community/signup/">Sign&nbsp;up</a></li></ul>
					<form action="/community/login/index.pl" method="post" id="myo-login" class="hide" name="toplogin">
					<div><a href="http:///" onclick="document.getElementById('myo-login').className = 'hide';document.getElementById('srch').className = 'show';return false;">
					<input name="cancel" value="close [x]" id="close" style="padding: 0pt 2px; float: right; margin-top: -12px; margin-right: 4px; font-size: 10px;" type="button"></a>
					<p><span class="m"><label for="username"><b><span>username:</span></b> 
					<input name="user" value="" maxlength="64" class="login" id="username" type="text"></label> </span>
					<span class="m"><label for="password"><b><span>password:</span></b> 
					<input name="passwd" value="" maxlength="64" class="login" id="password" type="password"></label> </span>
					<span class="m"><label for="rememberme">
					<span><input name="remember" value="1" id="rememberme" type="checkbox"> remember</span></label></span>
					 <span class="m"><input value=" log in " style="font-weight: bold;" type="submit"></span></p>
					 <p style="font-size: 10px; padding-top: 3px;" class="hidemobile">
					 <a href="http://my.opera.com/community/lostpw/">Lost password?</a> |
					  <a href="http://my.opera.com/community/help/">Help</a></p><p style="clear: both;" class="mobile" id="mbx">
					  <b><a href="http://my.opera.com/community/signup/">Sign&nbsp;up</a></b> |
					   <a href="http://my.opera.com/community/help/">Help</a></p></div></form></div></div>