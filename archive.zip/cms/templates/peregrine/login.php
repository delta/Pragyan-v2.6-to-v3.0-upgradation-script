 				<ul id="toplinx">
			 				<li   id="login">
 <a href="./+login" onclick="document.getElementById('login-box').className = 'show';document.getElementById('srch').className = 'hide';document.getElementById('username').focus();return false;">
					Log&nbsp;in</a></li>
					<li  ><a href="./+login&subaction=register">Sign&nbsp;up</a></li></ul>
 					<form action="./+login" method="post" id="login-box" class="hide" name="toplogin">
					<div><a href="#" onclick="document.getElementById('login-box').className = 'hide';document.getElementById('srch').className = 'show';return false;">
					<input name="cancel" value="close [x]" id="close" style="padding: 0pt 2px; float: right; margin-top: -12px; margin-right: 4px; font-size: 10px;" type="button"></a>
					<p><span class="m"><label for="username"><b><span>Email:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></b> 
					<input name="user_email" value="" maxlength="64" class="login" id="username" type="text"></label> </span>
					<span class="m"><label for="password"><b><span>Password:</span></b> 
					<input name="user_password" value="" maxlength="64" class="login" id="password" type="password"></label> </span>
					<span class="m">
					<span> <a href="./+login&subaction=resetPasswd">Lost password?</a></span></span>
					 <span class="m"><input value=" log in " style="font-weight: bold;" type="submit"></span></p>
					 </div></form>
					