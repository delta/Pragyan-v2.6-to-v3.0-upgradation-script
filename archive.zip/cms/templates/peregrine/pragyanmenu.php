<? 	global $urlRequestRoot; global $pageFullPath;
   	$url = rtrim($pageFullPath, '/');
	$urlPieces = explode('/', $url);
	$pageRoot = $urlPieces[1];
?>
<div id="menu">
<ul>
	<li id="home"><a href="/09/home" accesskey="1" <?= $pageRoot=="home"?'class="selected"':''?>><span>Home</span></a></li>
	<li id="events"><a href="/09/home/events" accesskey="2" <?= $pageRoot=="events"?'class="selected"':''?>><span>Events</span></a></li>
	<li id="gl"><a href="/09/home/guestlectures" accesskey="3" <?= $pageRoot=="guestlectures"?'class="selected"':''?>><span>Guest Lectures</span></a></li>
	<li id="workshops"><a href="/09/home/workshops" accesskey="4" <?= $pageRoot=="workshops"?'class="selected"':''?>><span>Workshops</span></a></li>
	<li id="info"><a href="/09/home/infotainment" accesskey="5" <?= $pageRoot=="infotainment"?'class="selected"':''?>><span>Infotainment</span></a></li>
	<li id="sponsors"><a href="/09/home/sponsors" accesskey="6" <?= $pageRoot=="sponsors"?'class="selected"':''?>><span>Partners</span></a></li>
	<li id="contacts"><a href="/09/home/jaagriti" accesskey="7" <?= $pageRoot=="jaagriti"?'class="selected"':''?>><span>Jagriti</span></a></li>
<li id="abtus"><a href="/09/home/contactus" accesskey="8" <?= $pageRoot=="contactus"?'class="selected"':''?>><span>Contact Us</span></a></li>	
	
	
	</ul>
	</div>
	