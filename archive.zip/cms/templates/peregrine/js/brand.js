(function() {
var f =
document.getElementById('searchbox_013069423422863237431:u9nytclvrk4');
if (!f) {
f = document.getElementById('searchbox_demo');
}
if (f &amp;&amp; f.q) {
var q = f.q;
var n = navigator;
var l = location;
if (n.platform == 'Win32') {
q.style.cssText = 'border: 1px solid #7e9db9; padding: 2px;';
}
var b = function() {
if (q.value == '') {
q.style.background = '#FFFFFF
url(http:\x2F\x2Fwww.google.com\x2Fcoop\x2Fintl\x2Fen\x2Fimages\x2Fgoogle_custom_search_watermark.gif)
left no-repeat';
}
};
var f = function() {
q.style.background = '#ffffff';
};
q.onfocus = f;
q.onblur = b;
if (!/[&amp;?]q=[^&amp;]/.test(l.search)) {
b();
}
}
})();
