<?php
// java script content start here
$body = <<<BODY




BODY;

// javascripts ends here..

$SIDEBARCONTENT = <<<SIDEBARCONTENT
	<div class="sponsor">
		<a href="$urlRequestRoot/sponsors">
			<div class="sponsor menuhead">Sponsor</div>
		</a>
  	<div class="sponsor-image">
  		<script language="javascript" type="text/javascript">
  		<!--
  			var imagesFolder = '$TEMPLATEBROWSERPATH/img/logos';
  		-->
  		</script>
  		<script language="JavaScript1.2" type="text/javascript" src="$TEMPLATEBROWSERPATH/sidebar.js"></script>
  	</div>
  </div>
SIDEBARCONTENT;

