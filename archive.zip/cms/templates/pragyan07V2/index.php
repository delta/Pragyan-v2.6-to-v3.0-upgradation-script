<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
<title><?= $TITLE ?></title>
<meta name="keywords" content="pragyan, 2009, 09, techfest, technical festival, festival, trichy, tiruchi, nitt, NITT, National Institute of Technology, Tituchirappalli, robovigyan, events, robotics" /><meta name="description" content="Pragyan, the annual international technical festival of National Institute of Techonlgy, Tiruchirappalli" />
<link rel="alternate" type="application/rss+xml" title="Pragyan 09 RSS feed" href="" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<meta http-equiv="Content-Language" content="English">
<meta name="Author" content="Pragyan 2009 Team">
<meta name="description" content="Pragyan 2009 : The International Technical Festival of NIT Trichy">
	<link rel="stylesheet" type="text/css" href="<?= $TEMPLATEBROWSERPATH ?>/css/main.css" media="screen,projection,print,tv" />
	<link rel="stylesheet" type="text/css" href="<?= $TEMPLATEBROWSERPATH ?>/css/other.css" />
	
<?php	
  //      <script language="javascript" type="text/javascript" src="Pragyan%2007%20-%20Annual%20Technical%20Festival%20of%20NIT%20Trichy_files/pari.js"></script>?>

		
		
		
<script language="javascript" type="text/javascript">
		//defined here for use in javascript
		var templateBrowserPath = "<?=$TEMPLATEBROWSERPATH ?>";
		var urlRequestRoot = "<?=$urlRequestRoot?>";
</script>
</head>


<body>
<a id="skipLink" href="#top">Jump to main content</a>
<div id="header">
	<div id="heading">
	<img src="<?= $TEMPLATEBROWSERPATH ?>/img/pragyan.png"  height="60" alt="Pragyan logo" />
	</div>
	
	       <? include("pragyanmenu.php");?>
	
</div>
<div id="wrap">
<div id="sidebar">
<div class="sidebarcomp" id="childbar">
<ul>
<h3><a href="events">Events</a></h3>
				<li><a href="#">Infotainment</a></li>
				<li><a href="#">RoboVigyan</a></li>
				<li><a href="#">General</a></li>
				<li><a href="#">Management</a></li>
				<li><a href="presentation">Presentation Events</a></li>
				<li><a href="electricalscience">Electrical Sciences</a></li>
				<li><a href="materialscience">Materials Sciences</a></li>
				<li><a href="modeling">Modeling</a></li>
				<li><a href="workingmodels">Working Models</a></li>
				<li><a href="mechanical">Mechanical Sciences</a></li>
				<li><a href="software">Software</a></li>
				</ul>
				</div>	     
	</div>
	
        <div id="rightbar">
   <div id="dates">
   <b>So  where will you be from </b><div style="border: 0px none ; font-weight: bold; font-size: 1.4em; color: rgb(36, 51, 66);">February 1 - 4 ?</div>
</div>
<div id="login">
 
	           		<?if($userId == 0) 
					{
					echo "<h3><a href=\"./+login\">Login</a></h3>";	
					} ?>

</div>

<div id="newsletter">
<h3>Newsletter</h3>
<form method="post" onsubmit="return checkEmail(this)" action="./?page=/newsletter&amp;action=user_create" id="display_frm" name="display_frm">
<input name="form_id" value="51" type="hidden">
<input name="action" value="user_create" type="hidden">
<input name="form_action" value="display_submit" type="hidden">
<input name="user_id" value="1" type="hidden">
<p align="center"><input name="data_1" id="input_box" value="Enter E-mail" onclick="javascript:this.value='';" onblur="javascript: if(this.value=='') this.value='Enter E-mail';" style="width: 100px;" type="text"><input name="type_1" value="text" type="hidden">
                 <br> <input onclick="javascript:checkEmail();" value="Subscribe" style="width: 90px;" type="button">
</p>
</form>
</div>	

	   <div id="mainsponsor">
	   <h3><a href="http://pragyan.org/07/?page=/sponsors">Sponsors</a></h3>
	   </div>
           
        </div>

		<a name="top" id="top" href="#"></a>
		<div id="content">
	<div id="actions_bar">
	<div id="breadcrumbs">
	           	<?= $BREADCRUMB ?>
	           	<?php
	           		global $userId;
	           		if($userId == 0) {
	           			echo "<div id=\"cms-actionbarPage\"><span class=\"cms-actionbarPageItem\"><a href=\"./+login\">Login</a></span></div>";
	           		}
	           	?>
				<?=(($userId==0)?"":$ACTIONBARPAGE)?>
				<?=(($userId==0)?"":$ACTIONBARMODULE)?>
            </div>
		</div>	
		
			
	<h1 class="firstHeading"></h1>
	<h2></h2>
					<?=$INFOSTRING?>
          			<?=$WARNINGSTRING?>
          			<?=$ERRORSTRING?>
          			<?=$CONTENT?>
	</div>
</div>
<?/*
<div id="footer">
	<div id="right">
<ul id="bottombar">
<li><a href="http://pragyan.org/07/search.php">Search</a></li>
<li><a href="http://pragyan.org/07/libs/rss.php" target="_blank"><img src="Pragyan%2007%20-%20Annual%20Technical%20Festival%20of%20NIT%20Trichy_files/feed-icon.png">Updates</a></li>
  <li><a href="http://pragyan.org/07/?page=/directions">Directions</a></li><li><a href="http://pragyan.org/07/?page=/sitemap">Site Map</a></li><li><a href="http://pragyan.org/07/?page=/media">Media</a></li><li><a href="http://pragyan.org/07/?page=/lookback">Lookback</a></li><li><a href="http://pragyan.org/07/?page=/contactus">Contacts</a></li>

<li><a href="http://www.nitt.edu/">NITT</a></li>
</ul>
<br>

        
      
	</div>	
	© Pragyan Team 2007<br>
<a href="mailto:webadmin@pragyan.org">webadmin@pragyan.org</a><br>

</div>
*/?>

<script language="javascript">                                                                                                                                                                                                                             
		 if(document.images)                                                                                                                                                                                                                                        
		   {                                                                                                                                                                                                                                                        
		     var i=0;                                                                                                                                                                                                                                               
		     var img_sp = new Array();                                                                                                                                                                                                                              
		     for(i=0;i<data.length;i++)                                                                                                                                                                                                                             
		       {                                                                                                                                                                                                                                                    
			 img_sp[i]=new Image();                                                                                                                                                                                                                             
			 img_sp[i].src=data[i][1];                                                                                                                                                                                                                          
		       }                                                                                                                                                                                                                                                    
		   }                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           
</script>   

</body></html>