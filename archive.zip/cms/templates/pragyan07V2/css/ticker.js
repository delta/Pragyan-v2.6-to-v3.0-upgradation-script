var t_index,t_link,t_img,ua,img;
t_index=0;
function change_image(id)
{
ua = navigator.userAgent;

//code for fading 
picContainer = document.getElementById(id);
if(typeof picContainer.style.MozOpacity=="string" && picContainer.style.MozOpacity<1)
{
setOpacity(picContainer,0);
//picContainer.style.MozOpacity=Math.min(parseFloat(picContainer.style.MozOpacity)+0.2, 0.99)
}
else if(picContainer.filters){
		document.getElementById(id).style.filter="blendTrans(duration=1)";
		document.getElementById(id).filters.blendTrans.Apply();
		
		}
//end of fading code
if(t_index  == data.length-1)
t_index=0;
t_img = document.getElementById(id);
t_link = document.getElementById(id+'_link');
t_img.src=data[t_index][1];
t_img.title = data[t_index][2];
t_link.href=data[t_index][0];
t_index++;

if(picContainer.filters)	
			document.getElementById(id).filters.blendTrans.Play();
else {
fadeIn(id,0);
}
	

}

function v_ticker(id)
{
change_image(id);
setTimeout("v_ticker('"+id+"')",2000);
}

function fadeIn(objId,opacity) {
  if (document.getElementById) {
    obj = document.getElementById(objId);
    if (opacity <= 100) {
      setOpacity(obj, opacity);
      opacity += 10;
      window.setTimeout("fadeIn('"+objId+"',"+opacity+")", 100);
    }
  }
}

function setOpacity(obj, opacity) {
  opacity = (opacity == 100)?99.999:opacity;
  
  // IE/Win
  obj.style.filter = "alpha(opacity:"+opacity+")";
  
  // Safari<1.2, Konqueror
  obj.style.KHTMLOpacity = opacity/100;
  
  // Older Mozilla and Firefox
  obj.style.MozOpacity = opacity/100;
  
  // Safari 1.2, newer Firefox and Mozilla, CSS3
  obj.style.opacity = opacity/100;
}
