function checkForm(formhandler)
{
var inputboxes=formhandler.getElementsByTagName("input");
var i;
  for(i=0;i<inputboxes.length;i++)
  {
    if(inputboxes[i].getAttribute('class')=="required")
    {
       if(inputboxes[i].value=="")
       {
	  alert('you have not filled in the form completely');
          return false;
       }
    }
  }
  return true;
}
