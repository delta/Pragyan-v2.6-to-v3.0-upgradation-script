<div id="topmenu">
<ul>
<li id="buy"><a href="#" accesskey="9"><span>About Pragyan</span></a></li>
<li id="contacts"><a href="#" accesskey="7"><span>Contact Us</span></a></li>
<li id="workshops"><a href="#" accesskey="4"><span>Workshops</span></a></li>
<li id="sponsors"><a href="#" accesskey="6"><span>Sponsors</span></a></li>
<li id="gl"><a href="#" accesskey="3"><span>Guest Lectures</span></a></li>
<li id="home"><a href="#" accesskey="1" class="selected"><span>Home</span></a></li>
</ul></div>