<?
global $SIDEBARCONTENT;
$date = date("l d M , h:ia");
$SIDEBARCONTENT = "<center id=\"sidebarcontent\">$date</center>";

